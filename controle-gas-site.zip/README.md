# Controle de Gás - Web e PDF

Este projeto oferece duas versões de um controle de estoque de gás:
- ✅ Um **site interativo** (HTML + JavaScript) que calcula automaticamente o valor total e o saldo de gás.
- 🗂️ Um **formulário PDF preenchível**, ideal para impressão ou preenchimento offline.

## Como usar

### 🔹 Versão Web
Abra o arquivo `index.html` no navegador. Basta preencher os campos — os cálculos são feitos automaticamente.

### 🔹 Versão PDF
Abra o arquivo `Controle_Gas_Form.pdf` com o Adobe Acrobat Reader ou um navegador moderno. Os campos podem ser preenchidos diretamente.

## Publicação no GitHub Pages

Para publicar o site:

1. Crie um repositório no GitHub com o nome `controle-gas-site`.
2. Envie os arquivos deste projeto.
3. Vá até as configurações do repositório, ative o **GitHub Pages** e selecione a branch principal.
4. Acesse via `https://seunome.github.io/controle-gas-site`.

## Licença

Este projeto é de uso livre.
